##############################################################
##############################################################
# Modelling
##############################################################
##############################################################

# libraries
library(glmnet)
library(ISLR)
library(leaps)
library(tree)
library(gbm)
library(rpart) #for fitting decision trees
library(randomForest)
library(doParallel)
library(caret)
library(xgboost)
library(e1071)


# import data
rm(list = ls())
setwd(dir = '/Users/Artur/ml22-team10')
train <- read.csv('./data/gold_data/train.csv')
val <- read.csv('./data/gold_data/val.csv')
test_X <- read.csv('./data/gold_data/test.csv')

# separate dependent and independent variables for training and validation set
train_X <- subset(train, select = -c(average_daily_rate))
train_y <- train$average_daily_rate

val_X <- subset(val, select = -c(average_daily_rate))
val_y <- val$average_daily_rate


# create a dataset to train the final model on with the train and validation set combined
train_and_val <- rbind(train, val)
train_and_val_X <- subset(train_and_val, select = -c(average_daily_rate))
train_and_val_y <- train_and_val$average_daily_rate

# inspect
str(train)
str(val)
str(test_X)
nrow(train)

#####@
# AAN TE PASSEN:
# 1) FOR EACH MODEL: DO HYPERPARAMETER TUNING ON TRAIN SET WITH CROSS VALIDATION
# 2) RETRAIN ON TRAIN SET WITH OPTIMAL PARAMETERS AND PREDICT ON VALIDATION SET
# 3) RETRAIN BEST-PERFORMING MODEL ON TRAIN + VAL SET TO PREDICT ON TEST SET


##############################################################
##############################################################
# Neural networks
##############################################################
##############################################################

# As these models become computationally very intensive, we set up parallel processing to speed
# up the process. Change number of clusters according to CPU
cluster <- makeCluster(detectCores()-1)
registerDoParallel(cluster)

# Besides, we also start saving our models so we do not have to run these models again

# you can close the parellel processing with the following code:
#stopCluster(cluster)
library(keras)
modelnn <- keras_model_sequential()
modelnn %>%
  layer_dense(units = 128, activation = "relu",
              input_shape = ncol(train_X)) %>%
  layer_dropout(rate = 0.3) %>%
  layer_dense(units = 64, activation = "relu",
              input_shape = ncol(train_X)) %>%
  layer_dropout(rate = 0.3) %>%
  layer_dense(units = 1, activation = "linear")
modelnn


modelnn %>% compile(loss = "mse",
                    optimizer = optimizer_rmsprop(),
                    metrics = list("mean_squared_error"))

#
x_train <- model.matrix(average_daily_rate ~ ., data = train)[, -1]
y_train <- train$average_daily_rate

x_val <- model.matrix(average_daily_rate ~ ., data = val)[, -1]
y_val <- val$average_daily_rate

early_stop <- callback_early_stopping(monitor = "val_loss", patience = 20)

# Fit the model and store training stats
history <- modelnn %>%
  fit(x_train, y_train, epochs = 500, batch_size = 128,
      validation_data = list(x_val, y_val),
      verbose = 1,
      callbacks = list(early_stop))

# predict on validation set
nn_run1_pred_val <- modelnn %>% predict(x_val)
score <- sqrt(mean((nn_run1_pred_val - val_y)^2))
score
