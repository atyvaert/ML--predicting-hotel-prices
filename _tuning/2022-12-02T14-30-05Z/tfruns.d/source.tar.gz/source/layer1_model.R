
##############
# wide model with 1 layer
#############


# build the neural network
one.layer.model <- function() {
  model <- keras_model_sequential() 
  model %>%
    layer_dense(units = FLAGS$neurons1, activation = "relu",
                input_shape = ncol(x_train)) %>%
    layer_dropout(rate = FLAGS$dropout1) %>%
    layer_dense(units = 1, activation = "linear")
  
  model %>% compile(
    loss = "mse",
    optimizer = optimizer_rmsprop(learning_rate = FLAGS$lr),
    metrics = list("mean_squared_error")
  )
  model
}

layer1_model <- build_model()
layer1_model %>% summary()


early_stop <- callback_early_stopping(monitor = "val_loss", patience = 3)

epochs <- 50


# Fit the model and store training stats
history <- layer1_model %>%
  fit(x_train, y_train, epochs = epochs, batch_size = 128,
      validation_data = list(x_val, y_val),
      verbose = 1,
      callbacks = list(early_stop))


# predict on validation set
nn_pred_val <- layer1_model %>% predict(x_val)
score <- sqrt(mean((nn_pred_val - val_y)^2))
score

# save
save_model_hdf5(layer1_model, './model.h5')








