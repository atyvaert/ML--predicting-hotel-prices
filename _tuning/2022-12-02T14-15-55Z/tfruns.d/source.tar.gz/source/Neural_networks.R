##############################################################
##############################################################
# Modelling
##############################################################
##############################################################

# libraries
library(glmnet)
library(ISLR)
library(leaps)
library(tree)
library(gbm)
library(rpart) #for fitting decision trees
library(randomForest)
library(doParallel)
library(caret)
library(xgboost)
library(e1071)


# import data
rm(list = ls())
setwd(dir = '/Users/Artur/ml22-team10')
train <- read.csv('./data/gold_data/train.csv')
val <- read.csv('./data/gold_data/val.csv')
test_X <- read.csv('./data/gold_data/test.csv')

# separate dependent and independent variables for training and validation set
train_X <- subset(train, select = -c(average_daily_rate))
train_y <- train$average_daily_rate

val_X <- subset(val, select = -c(average_daily_rate))
val_y <- val$average_daily_rate


# create a dataset to train the final model on with the train and validation set combined
train_and_val <- rbind(train, val)
train_and_val_X <- subset(train_and_val, select = -c(average_daily_rate))
train_and_val_y <- train_and_val$average_daily_rate

# inspect
str(train)
str(val)
str(test_X)
nrow(train)

#####@
# AAN TE PASSEN:
# 1) FOR EACH MODEL: DO HYPERPARAMETER TUNING ON TRAIN SET WITH CROSS VALIDATION
# 2) RETRAIN ON TRAIN SET WITH OPTIMAL PARAMETERS AND PREDICT ON VALIDATION SET
# 3) RETRAIN BEST-PERFORMING MODEL ON TRAIN + VAL SET TO PREDICT ON TEST SET


##############################################################
##############################################################
# Neural networks
##############################################################
##############################################################

# As these models become computationally very intensive, we set up parallel processing to speed
# up the process. Change number of clusters according to CPU
cluster <- makeCluster(detectCores()-1)
registerDoParallel(cluster)

# Besides, we also start saving our models so we do not have to run these models again

# you can close the parellel processing with the following code:
#stopCluster(cluster)
library(keras)
modelnn <- keras_model_sequential()
modelnn %>%
  layer_dense(units = 256, activation = "relu",
              input_shape = ncol(train_X)) %>%
  layer_dropout(rate = 0.4) %>%
  layer_dense(units = 128, activation = "relu") %>%
  layer_dropout(rate = 0.3) %>%
  layer_dense(units = 1, activation = "linear")
modelnn


modelnn %>% compile(loss = "mse",
                  optimizer = optimizer_rmsprop(),
                  metrics = list("mean_squared_error"))

#
x_train <- model.matrix(average_daily_rate ~ ., data = train)[, -1]
y_train <- train$average_daily_rate

x_val <- model.matrix(average_daily_rate ~ ., data = val)[, -1]
y_val <- val$average_daily_rate



system.time(
  history <- modelnn %>%
    fit(x_train, y_train, epochs = 30, batch_size = 128,
        validation_data = list(x_val, y_val),
        callbacks = print_dot_callback))

history
plot(history, smooth = FALSE)

# build the otpimal neural network architecture
# The approach to finding the optimal neural network model will have some tweakable constants.
# We start with a number of layers equal to one, but we will increase this number later.
# Further, we have a minimum of 64 and a maximum of 256 neurons per layer. The step size between the number
# of neurons will be 64, giving a wide range of possibilities.
# https://towardsdatascience.com/how-to-find-optimal-neural-network-architecture-with-tensorflow-the-easy-way-50575a03d060



# Use this guide
# https://www.roelpeters.be/using-keras-in-r-hypertuning-a-model/


# In essence, hypertuning is done through flags. Anywhere in your neural network, 
# you can replace a parameter with a flag
FLAGS <- flags(
  flag_numeric('dropout1', 0.3),
  flag_integer('neurons1', 128),
  flag_integer('neurons2', 128),
  flag_integer('neurons3', 128),
  flag_numeric('l2', 0.001),
  flag_numeric('lr', 0.001)
)

par <- list(
  dropout1 = c(0.2,0.3,0.4,0.5),
  neurons1 = c(64,128,256, 512),
  neurons2 = c(64,128,256),
  lr = c(0.00001,0.0001,0.001,0.01)
)

# build the neural network
build_model <- function() {
  model <- keras_model_sequential() 
  model %>%
    layer_dense(units = FLAGS$neurons1, activation = "relu",
                input_shape = ncol(x_train)) %>%
    layer_dropout(rate = FLAGS$dropout1) %>%
    layer_dense(units = FLAGS$neurons2, activation = "relu") %>%
    layer_dropout(rate = FLAGS$dropout1) %>%
    layer_dense(units = 1, activation = "linear")
  
  model %>% compile(
    loss = "mse",
    optimizer = optimizer_rmsprop(learning_rate = FLAGS$lr),
    metrics = list("mean_squared_error")
  )
  model
}

model <- build_model()
model %>% summary()


early_stop <- callback_early_stopping(monitor = "val_loss", patience = 3)

epochs <- 50


# Fit the model and store training stats
history <- model %>%
  fit(x_train, y_train, epochs = epochs, batch_size = 128,
      validation_data = list(x_val, y_val),
      verbose = 1,
      callbacks = list(early_stop))


# predict on validation set
nn_pred_val <- model %>% predict(x_val)
score <- sqrt(mean((nn_pred_val - val_y)^2))
score

##############
# wide model with 1 layer
#############
par <- list(
  dropout1 = c(0.2,0.3,0.4,0.5),
  neurons1 = c(64,128,256, 512),
  lr = c(0.00001,0.0001,0.001,0.01)
)

# build the neural network
one.layer.model <- function() {
  model <- keras_model_sequential() 
  model %>%
    layer_dense(units = FLAGS$neurons1, activation = "relu",
                input_shape = ncol(x_train)) %>%
    layer_dropout(rate = FLAGS$dropout1) %>%
    layer_dense(units = 1, activation = "linear")
  
  model %>% compile(
    loss = "mse",
    optimizer = optimizer_rmsprop(learning_rate = FLAGS$lr),
    metrics = list("mean_squared_error")
  )
  model
}

layer1_model <- build_model()
layer1_model %>% summary()


early_stop <- callback_early_stopping(monitor = "val_loss", patience = 3)

epochs <- 50


# Fit the model and store training stats
history <- layer1_model %>%
  fit(x_train, y_train, epochs = epochs, batch_size = 128,
      validation_data = list(x_val, y_val),
      verbose = 1,
      callbacks = list(early_stop))


# predict on validation set
nn_pred_val <- layer1_model %>% predict(x_val)
score <- sqrt(mean((nn_pred_val - val_y)^2))
score

# save
save(layer1_model, file = './nn_models/layer1.Rdata')


# In the following lines of code I define the possible values of all the parameters I want to hypertune. 
# This will produce a lot of possible combinations of parameters. 
# That’s why in the tuning_run() function, I specify I only want to try 10% of the possible combinations (sampled).
if(!require('tfruns')) install.packages('tfruns')
library(tfruns)
par <- list(
  dropout1 = c(0.2,0.3,0.4,0.5),
  neurons1 = c(64,128,256, 512),
  lr = c(0.00001,0.0001,0.001,0.01)
)
runs <- tuning_run('/Users/Artur/layer1_model.R', runs_dir = '_tuning', flags = par)


# Finally, I simply list all the runs, by referring to its running directory, where all the information 
# from the run is stored and I ask for it to be ordered according to the mean squared error.
ls_runs(order = metric_val_mean_absolute_error, decreasing= F, runs_dir = '_tuning')

# Finally, I select the best model parameters and I train the model with it.
best_run <- ls_runs(order = metric_val_mean_absolute_error, decreasing= F, runs_dir = '_tuning')[1,]

run <- training_run('nn_ht.R',flags = list(
  dropout1 = best_run$flag_dropout1,
  neurons1 = best_run$flag_neurons1,
  neurons2 = best_run$flag_neurons2,
  neurons3 = best_run$flag_neurons3,
  l2 = best_run$flag_l2,
  lr = best_run$flag_lr))

best_model <- load_model_hdf5('model.h5')










#######################@
# to test the best model
#######################
x_test <- as.matrix(test_X[, -1])





