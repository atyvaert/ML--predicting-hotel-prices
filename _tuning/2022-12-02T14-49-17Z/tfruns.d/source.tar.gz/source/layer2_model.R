# In essence, hypertuning is done through flags. Anywhere in your neural network, 
# you can replace a parameter with a flag
FLAGS <- flags(
  flag_numeric('dropout1', 0.3),
  flag_integer('neurons1', 128),
  flag_integer('neurons2', 128),
  flag_numeric('lr', 0.001)
)



# build the neural network
build_model <- function() {
  model <- keras_model_sequential() 
  model %>%
    layer_dense(units = FLAGS$neurons1, activation = "relu",
                input_shape = ncol(x_train)) %>%
    layer_dropout(rate = FLAGS$dropout1) %>%
    layer_dense(units = FLAGS$neurons2, activation = "relu") %>%
    layer_dropout(rate = FLAGS$dropout1) %>%
    layer_dense(units = 1, activation = "linear")
  
  model %>% compile(
    loss = "mse",
    optimizer = optimizer_rmsprop(learning_rate = FLAGS$lr),
    metrics = list("mean_squared_error")
  )
  model
}

model <- build_model()
model %>% summary()


early_stop <- callback_early_stopping(monitor = "val_loss", patience = 3)

epochs <- 50


# Fit the model and store training stats
history <- model %>%
  fit(x_train, y_train, epochs = epochs, batch_size = 128,
      validation_data = list(x_val, y_val),
      verbose = 1,
      callbacks = list(early_stop))

# predict on validation set
nn_pred_val <- layer1_model %>% predict(x_val)
score <- sqrt(mean((nn_pred_val - val_y)^2))
score

# save
# save(layer2_model, file = './nn_models/layer2.Rdata')

