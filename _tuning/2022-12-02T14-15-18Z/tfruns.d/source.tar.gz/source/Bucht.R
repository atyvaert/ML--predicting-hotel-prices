# was voor pyton
num_layers = 3
min_nodes_per_layer = 64
max_nodes_per_layer = 256
node_step_size = 64

# look at the range of options for the neurons
node_options = array(seq(
  min_nodes_per_layer, 
  max_nodes_per_layer + 1, 
  node_step_size
))
node_options

library(itertools)
layer_possibilities = rep(list(node_options), num_layers)
layer_possibilities
layer_node_permutations = list(expand.grid(layer_possibilities))
layer_node_permutations



for (permutation in layer_node_permutations){
  for (nodes_at_layer in permutation){
    print(nodes_at_layer)
  }
  print(' /n ')
}

for (permutation in layer_node_permutations){
  print(permutation[3])
}



models = list()



print_dot_callback <- callback_lambda(
  on_epoch_end = function(epoch, logs) {
    if (epoch %% 5 == 0) cat("\n")
    cat(".")
  }
)


# create a function:
get_models <- function(num_layers,
                       min_nodes_per_layer,
                       max_nodes_per_layer,
                       node_step_size,
                       input_shape,
                       hidden_layer_activation = 'relu',
                       num_nodes_at_output = 1,
                       output_layer_activation = 'linear') {
  
  node_options = array(seq(min_nodes_per_layer, max_nodes_per_layer + 1, node_step_size))
  layer_possibilities = rep(list(node_options), num_layers)
  layer_node_permutations = list(expand.grid(layer_possibilities))
  
  models = list()
  
  for (permutation in layer_node_permutations){
    model <- keras_model_sequential()
    model %>%
      layer_dense(units = permutation[1], activation = "relu",
                  input_shape = input_shape) %>%
      layer_dropout(rate = 0.4) %>%
      layer_dense(units = 1, activation = "linear")
    
    history <- model %>%
      fit(x_train, y_train, epochs = 30, batch_size = 128,
          validation_data = list(x_val, y_val),
          callbacks = print_dot_callback)
    
    models.append(history)
  }
  
  
  
  model = tf.keras.Sequential()
  model.add(tf.keras.layers.InputLayer(input_shape=input_shape))
  model_name = ''
  
  
  model.add(tf.keras.layers.Dense(num_nodes_at_output, activation=output_layer_activation))
  model._name = model_name[:-1]
  models.append(model)
  
}





model <- keras_model_sequential()
model %>%
  layer_dense(units = permutation[1], activation = "relu",
              input_shape = input_shape) %>%
  layer_dropout(rate = 0.4) %>%
  layer_dense(units = permutation[2], activation = "relu") %>%
  layer_dropout(rate = 0.3) %>%
  layer_dense(units = 1, activation = "linear")



print_dot_callback <- callback_lambda(
  on_epoch_end = function(epoch, logs) {
    if (epoch %% 80 == 0) cat("\n")
    cat(".")
  }
)
